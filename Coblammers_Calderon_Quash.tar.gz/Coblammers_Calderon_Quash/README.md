# Quash
Operating Systems Project 1

To run quash (Quite a Shell), begin by compiling the code by entering 'make' while in the Quash directory.
Simply run quash by entering './quash', and the shell is up and running!

